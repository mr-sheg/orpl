"""
System Response Correction
================

Provides Raman spectrum instrument/system response correction tools and xaxis calibration.
"""
import numpy as np
from scipy.signal import find_peaks

# Wavelenghts shift calibration (x-axis)
# Xaxis tools


def nm2icm(nm, nm0=785):
    """
    Converts wavelenghts from nanometers to cm-1

    Usage
    ------
    icm = nm2icm(nm, nm0)

    Input arguments
    ----------------
    nm          --> [NDARRAY] xaxis in [nm]

    nm0         --> [float] wavelenght of the excitation source [nm]

    Outputs
    -------
    icm         --> [NDARRAY] xaxis in [cm-1]
    """
    nm = np.array(nm)
    icm = (1 / nm0 - 1 / nm) * 1e7
    return icm


def icm2nm(icm, nm0=785):
    """
    Converts an xaxis [cm-1] into an xaxis [nm].

    Usage
    ------
    nm = icm2nm(icm, nm0)

    Input arguments
    ----------------
    icm         --> [NDARRAY] xaxis in [cm-1]

    nm0         --> [float] wavelenght of the excitation source [nm]

    Outputs
    -------
    nm          --> [NDARRAY] xaxis in [nm]
    """
    icm = np.array(icm)
    nm = 1 / (1 / nm0 - icm * 1e-7)
    return nm


def auto_fpeak(spectrum, ntarget, metric="prominence"):
    """
    Find n (ntarget) peaks in a spectrum (s) by automatic adjustment of
    a metric using scipy.signal.find_peaks and a bisection method

    Usage
    ------
    pid = auto_fpeak(s, ntarget)

    Input arguments
    ----------------
    s            --> [NDARRAY] spectrum

    ntarget      --> [int] number of peaks to find

    metric       --> [str] metric to use for the bisection method.
                    Possible values are ['prominence', 'height']

    Outputs
    -------
    pid          --> [NDARRAY] peak indexes
    """

    # check if metric is supported
    supported = ["prominence", "height"]
    if metric not in supported:
        raise ValueError("Unsupported metric. Possible metric are " + str(supported))

    spectrum_ = spectrum / spectrum.max()
    threshold = 1
    npeakfound = 0

    while npeakfound is not ntarget:

        if metric == "prominence":
            pid, _ = find_peaks(spectrum_, prominence=threshold)
        elif metric == "height":
            pid, _ = find_peaks(spectrum_, height=threshold)

        npeakfound = pid.size
        if npeakfound > ntarget:
            threshold = 1.5 * threshold
        else:
            threshold = 0.5 * threshold

    return pid


def genx_fref(spectrum, refx, refy, npks, deg=2):
    """
    Generates an xaxis for a spectrum based on a reference spectrum (with)
    an xaxis. Experimental spectrum peaks are compared with reference
    spectrum peaks and a reference xaxis to generate the xaxis for the
    experimental spectrum.

    This algorithm is heavily depends on the auto_fpeak peak finder.

    Usage
    ------
    xaxis = genx_fref(spectrum, refx, refy, npks, deg=2, debug=False)

    Input arguments
    ----------------
    spectrum    --> [NDARRAY] sample measured spectrum

    refx        --> [NDARRAY] sample reference spectrum xaxis

    refy        --> [NDARRAY] sample reference spectrum

    npks        --> [int] number of peaks to use/find with auto_fpeak

    deg         --> [int] the degree of the xaxis polynomial model

    debug       --> [boolean] if true, plots showing the spectrum, refy
                    and identified peaks will be drawn.

    Outputs
    -------
    xaxis       --> [NDARRAY] the generated xaxis
    """
    # Normalization of spectrum
    expy = spectrum / spectrum.max()
    refy = refy / refy.max()

    # Find peaks
    exp_pid = auto_fpeak(expy, npks)
    ref_pid = auto_fpeak(refy, npks)

    ref_p = refx[ref_pid]

    coefs = np.polyfit(exp_pid, ref_p, deg=deg)
    xaxis = np.polynomial.polynomial.polyval(np.arange(expy.size), coefs[::-1])
    return xaxis


def genx_fpks(spectrum, pks, deg=2):
    """
    Generates an xaxis for a spectrum based on a list of specified peak
    positions.

    This algorithm is heavily depends on the auto_fpeak peak finder.

    Usage
    ------
    xaxis = genx_fpks(spectrum, pks, deg=2, debug=False)

    Input arguments
    ----------------
    spectrum    --> [NDARRAY] sample measured spectrum

    pks         --> [list] xaxis positions of peaks

    deg         --> [int] the degree of the xaxis polynomial model

    debug       --> [boolean] if true, a plot showing the spectrum and
                    identified peaks will be drawn.

    Outputs
    -------
    xaxis       --> [NDARRAY] the generated xaxis
    """
    # Normalization of spectrum
    expy = spectrum / spectrum.max()

    # Find peaks
    npks = len(pks)
    exp_pid = auto_fpeak(expy, npks)

    coefs = np.polyfit(exp_pid, pks, deg=deg)
    xaxis = np.polynomial.polynomial.polyval(np.arange(expy.size), coefs[::-1])
    return xaxis


def autogenx(spectrum, preset="tylenol", deg=2):
    """
    automatic xaxis generation from preset.

    This algorithm is heavily depends on the auto_fpeak peak finder.

    Usage
    ------
    xaxis = autogenx(spectrum, preset, debug=False)

    Input arguments
    ----------------
    spectrum    --> [NDARRAY] sample measured spectrum

    preset      --> [str] name of a preset to use.
                    choose from ['tylenol', 'nylon']

    debug       --> [boolean] if true, a plot showing the spectrum and
                    identified peaks will be drawn.

    Outputs
    -------
    xaxis       --> [NDARRAY] the generated xaxis
    """
    preset_pks_pos = {
        "tylenol": [797.2, 857.9, 1168.5, 1236.8, 1323.9, 1609, 1648.4],
        "nylon": [956.1, 1064.2, 1131.7, 1235.1, 1298.5, 1442.8, 1631.6],
    }

    if preset not in preset_pks_pos.keys():
        raise ValueError(f"Invalid preset. Choose from {preset_pks_pos.keys()}")

    xaxis = genx_fpks(spectrum, preset_pks_pos[preset], deg=deg)

    return xaxis


# Intensity calibrations (y-axis)

# NIST correction
NIST_COEFS = [
    9.71937e-02,
    2.28325e-04,
    -5.86762e-08,
    2.16023e-10,
    -9.77171e-14,
    1.15596e-17,
]


def compute_irf(measured_nist: np.ndarray, xaxis: np.ndarray = None):
    """
    compute_irf computes an Instrument Response Function (IRF) from a measured
    NIST raman spectrum. The IRF can be used to perform a relative intensity
    correction of a measured spectrum;

    corrected_spectrum = measured_spectrum / IRF

    Usage
    ------
        instrument_response = getCorrectionCurve(measured_nist, xaxis=None)

    Input arguments
    ----------------
        measured_nist [NDARRAY]:
            Measured NIST standard spectrum

        xaxis=None [NDARRAY]:
            xaxis of the system in cm-1 (should match size of
            measured_nist). If None, the computation will be made in camera
            pixels and will not be accurate as the NIST coefficients are
            given in cm-1 units.

    Outputs
    -------
        instrument_response  --> The system instrument response
    """

    # computing theoretical NIST response for a system's WL range
    if xaxis is None:
        xaxis = np.array(range(0, len(measured_nist)))

    nist_theoretical = np.zeros(xaxis.shape)
    for i, coef in enumerate(NIST_COEFS):
        nist_theoretical += coef * xaxis**i

    # Computing correction curve
    # measured_nist = measured_nist / measured_nist.max()
    instrument_response = measured_nist / nist_theoretical
    instrument_response = instrument_response / instrument_response.max()

    return instrument_response
